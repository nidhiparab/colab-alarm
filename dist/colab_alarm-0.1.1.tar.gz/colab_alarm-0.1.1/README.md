# Colab Alarm

A simple audio notification system for Google Colab notebooks. Play an alarm sound when your cell finishes executing.

## Installation

```bash
pip install colab-alarm